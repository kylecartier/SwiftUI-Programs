//
//  ContentView.swift
//  Calculator
//
//  Created by Kyle Cartier on 3/20/25.
//

import SwiftUI

// What the buttons will say!
enum CalcButton: String {
    case one = "1"
    case two = "2"
    case three = "3"
    case four = "4"
    case five = "5"
    case six = "6"
    case seven = "7"
    case eight = "8"
    case nine = "9"
    case zero = "0"
    case add = "+"
    case subtract = "-"
    case multiply = "x"
    case divide = "/"
    case equal = "="
    case negative = "+/-"
    case clear = "AC"
    
    // Make the colors for each set of buttons
    var buttonColor: Color {
        switch self {
        case .add, .subtract, .multiply, .divide, .equal:
            return Color(UIColor(red: 45/250, green: 45/250, blue: 25/250, alpha:1))
        case .clear, .negative:
            return Color(UIColor(red: 40/250, green: 60/250, blue: 60/250, alpha:1))
        default:
            return Color(UIColor(red: 70/250, green: 55/250, blue: 55/250, alpha:1))
        }
    }
}

// Perform Operations
enum Operation {
    case add, subtract, multiply, divide, none
}

struct ContentView: View {
    
    @State var value = "0"
    @State var runningNumber = 0
    @State var currentValue = 0
    @State var currentOperation: Operation = .none
    
    // What the buttons will be
    let buttons: [[CalcButton]] = [
        [.clear, .negative, .divide],
        [.seven, .eight, .nine, .multiply],
        [.four, .five, .six, .subtract],
        [.one, .two, .three, .add],
        [.zero, .equal],
    ]
    
    // Form the Calculator!
    var body: some View {
        ZStack {
            Color(UIColor(red: 30/250, green: 30/250, blue: 30/250, alpha:1)).ignoresSafeArea(edges: .all)
            VStack {
                Spacer()
                
                // Dsiplay Text
                HStack {
                    Spacer()
                    Text(value)
                        .bold(true)
                        .font(.system(size: 100))
                        .foregroundColor(.white)
                }
                
                // Display Buttons
                ForEach(buttons, id: \.self) { row in
                    HStack(spacing: 12) {
                        ForEach(row, id: \.self) { char in
                            Button(action: {
                                self.didTap(button: char)
                            }, label: {
                                Text(char.rawValue)
                                    .frame(
                                        width: self.buttonWidth(char: char),
                                        height: self.buttonHeight()
                                    )
                                    .font(.system(size: 32))
                                    .background(char.buttonColor)
                                    .foregroundColor(.white)
                                    .cornerRadius(self.buttonWidth(char: char)/20)
                                    .padding(.bottom, 8)
                            })
                        }
                    }
                }
            }
        }
    }
    
    // How the buttons work!
    func didTap(button: CalcButton) {
        switch button {
        case .add, .subtract, .multiply, .divide, .equal:
            if button == .add {
                self.currentOperation = .add
                self.runningNumber = Int(self.value) ?? 0
            }
            else if button == .subtract {
                self.currentOperation = .subtract
                self.runningNumber =  Int(self.value) ?? 0
            }
            else if button == .multiply {
                self.currentOperation = .multiply
                self.runningNumber = Int(self.value) ?? 0
            }
            else if button == .divide {
                self.currentOperation = .divide
                self.runningNumber = Int(self.value) ?? 0
            }
            else if button == .equal {
                let runningValue = Int(self.runningNumber)
                let currentValue = Int(self.value)
                switch self.currentOperation {
                case .add: self.value = "\(runningValue + (currentValue ?? 0))"
                case .subtract: self.value = "\(runningValue - (currentValue ?? 0))"
                case .multiply: self.value = "\(runningValue * (currentValue ?? 0))"
                case .divide: self.value = "\(runningValue / (currentValue ?? 0))"
                case .none:
                    break
                }
            }
            
            if button != .equal {
                self.value = ""
            }
        
        case .clear: self.value = "0"
        case .negative: self.value = "-"
        
            
        default:
            let number = button.rawValue
            if self.value == "0" {
                value = number
            }
            else {
                self.value = "\(self.value)\(number)"
            }
        }
    }
    
    // Button Width and Height
    func buttonWidth(char: CalcButton) -> CGFloat {
        if char == .zero {
            return ((UIScreen.main.bounds.width - (5*8)) / 4) * 3
        }
        else if char == .clear {
            return ((UIScreen.main.bounds.width - (5*12)) / 4) * 2
        }
        return (UIScreen.main.bounds.width - (6*12)) / 4
    }
    
    func buttonHeight() -> CGFloat {
        return ((UIScreen.main.bounds.width - (6*12)) / 4)
    }
}

// End of the code
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
